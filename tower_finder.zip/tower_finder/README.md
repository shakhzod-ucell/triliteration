# 📡 Cell Tower Discovery Engine

Reverse-engineers the physical location of LTE cell towers (eNodeBs) using only
passive observations from mobile users — no operator cooperation required.

---

## What It Does

When a 4G device connects to a tower, the network sends it a **Timing Advance (TA)**
value that encodes the round-trip signal travel time. This translates directly to
the distance between the user and the tower:

```
distance (meters) = (TA × 78.125) + 39.0625
```

If we collect enough user observations around an unknown tower, each one draws a
ring at that radius. The rings intersect at one point — the tower itself.

**Input:** CSV with user GPS positions, LTE Timing Advance, eNBid, CidRaw  
**Output:** Map + CSV of discovered tower locations with confidence scores

---

## Project Structure

```
tower_finder/
├── src/
│   ├── loader.py          # Data ingestion, parsing, filtering
│   ├── trilateration.py   # Core math engine (ring intersection)
│   ├── export.py          # Folium map + CSV generation
│   └── validate.py        # Merge with ground truth, accuracy report
├── run_pipeline.py        # Main entry point — runs full pipeline
├── make_report.py         # Generates Excel accuracy table
├── requirements.txt
└── README.md
```

---

## Quick Start

```bash
pip install -r requirements.txt

# Full pipeline: load → filter → trilaterate → map
python run_pipeline.py --input your_data.csv

# After you have ground truth:
python run_pipeline.py --input your_data.csv --ground-truth sites.csv

# Excel accuracy report (needs merged_towers.csv from pipeline):
python make_report.py
```

---

## Data Format

Your input CSV has a duplicate `@timestamp` header and a non-standard location field.
The pipeline handles both automatically.

```
@timestamp, LocationSeconds, location,              @timestamp, AppName, LteRsrp, eNBid, ConnectionType, LteTimingAdvance, Cid, CidRaw
2026-03-03, 3,              {"lat":41.18|"lon":69.32}, ...,   -107,    1160,  4G,    7,               40,  297000
```

**Key field relationships (verified 100% on your data):**
```
CidRaw  = eNBid × 256 + Cid     ← CidRaw IS the full ECI
eNBid   = CidRaw >> 8           ← upper 20 bits = physical tower
Cid     = CidRaw & 0xFF         ← lower 8 bits  = sector (0, 1, 2...)
```

One physical tower (eNBid) can have up to 3 sectors (Cid 0/1/2). The engine
groups by eNBid so all sectors from the same mast are used together.

---

## Ground Truth Merge

Your operator site file uses `eci` column. The join key:
```
GT eci >> 8  ==  predicted eNBid
```
The merge applies a 50 km proximity filter to reject cross-operator eNBid collisions
(same number reused by different operators in different cities).

---

## Accuracy Results (on your dataset)

| Tier   | Towers | Median Error | Within 200m |
|--------|--------|-------------|-------------|
| HIGH   | 168    | **34 m**    | 98.2%       |
| MEDIUM | 234    | **53 m**    | 97.4%       |
| LOW    | 248    | **80 m**    | 77.4%       |
| **All**| **650**| **53 m**    | **90.0%**   |

Based on 3,285,048 measurements across 2,419 discovered towers.

---

## Pipeline Stages

| Stage | Module | What Happens |
|-------|--------|-------------|
| 1 | `loader.py` | Parse pipe-separated location, rename duplicate headers, convert TA→meters, compute quality weights |
| 2 | `loader.py` | Filter: 4G only, valid GPS, TA 0–150, LocationSeconds ≤ 30 |
| 3 | `trilateration.py` | Group by eNBid, run weighted least-squares ring intersection with multi-start |
| 4 | `trilateration.py` | Score each tower: angular coverage + measurement count + residual error |
| 5 | `export.py` | Save CSV, build Folium interactive map with confidence-colored markers |
| 6 | `validate.py` | Merge with GT via ECI→eNBid, proximity filter, compute real error per tower |
| 7 | `make_report.py` | Excel table: SITE_NAME / Отклонение (м) / Кол-во замеров |

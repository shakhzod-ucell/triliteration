"""
run_pipeline.py
---------------
Main entry point. Runs the full pipeline end-to-end.

Usage:
    python run_pipeline.py --input data.csv
    python run_pipeline.py --input data.csv --ground-truth sites.csv
    python run_pipeline.py --input data.csv --ground-truth sites.csv --out-dir results/
"""

import argparse
import sys
import time
from pathlib import Path

# Make src/ importable when running from project root
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from loader        import load_and_clean
from trilateration import run_trilateration
from export        import save_csv, build_map, build_validation_map
from validate      import load_ground_truth, merge_with_ground_truth


def main():
    parser = argparse.ArgumentParser(description='Cell Tower Discovery Engine')
    parser.add_argument('--input',        required=True, help='Raw measurement CSV')
    parser.add_argument('--ground-truth', default=None,  help='Operator site CSV (optional)')
    parser.add_argument('--out-dir',      default='.',   help='Output directory (default: .)')
    args = parser.parse_args()

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    t0 = time.time()

    # ── Stage 1: Load & clean ────────────────────────────────────────────
    print("\n" + "═"*55)
    print("  STAGE 1 — Load & Filter")
    print("═"*55)
    df = load_and_clean(args.input)

    # ── Stage 2: Trilateration ───────────────────────────────────────────
    print("\n" + "═"*55)
    print("  STAGE 2 — Trilateration")
    print("═"*55)
    towers = run_trilateration(df)

    # ── Stage 3: Export ──────────────────────────────────────────────────
    print("\n" + "═"*55)
    print("  STAGE 3 — Export")
    print("═"*55)
    csv_path = out / 'calculated_towers.csv'
    map_path = out / 'towers_map.html'
    save_csv(towers, str(csv_path))
    build_map(towers, str(map_path))

    # ── Stage 4: Validate (optional) ─────────────────────────────────────
    if args.ground_truth:
        print("\n" + "═"*55)
        print("  STAGE 4 — Ground Truth Validation")
        print("═"*55)
        gt_raw  = load_ground_truth(args.ground_truth)
        matched, unmatched = merge_with_ground_truth(towers, gt_raw)

        matched_path   = out / 'merged_towers.csv'
        unmatched_path = out / 'unmatched_towers.csv'
        val_map_path   = out / 'validation_map.html'

        matched.sort_values('error_m').to_csv(matched_path, index=False)
        unmatched.to_csv(unmatched_path, index=False)
        build_validation_map(matched, str(val_map_path))

        print(f"\n  ✅ {matched_path}")
        print(f"  ✅ {unmatched_path}")

    # ── Done ─────────────────────────────────────────────────────────────
    elapsed = time.time() - t0
    print(f"\n{'═'*55}")
    print(f"  DONE in {elapsed:.1f}s")
    print(f"  Output files in: {out.resolve()}")
    print(f"{'═'*55}\n")


if __name__ == '__main__':
    main()
